/* 
Marissa A. Mocenigo
Tuesday, April 21, 2009

Declaration of structs for each linked list and function prototypes

*/


typedef struct data {
  int year;
  int rank;
  double usage;
  struct data *next;
} Data;


typedef struct name {
  char name[20];
  double largest;
  struct name *next;
  Data *head;
  Data *tail;
} Name;

typedef struct file {
  char filename[10];
  struct file *next;
} File; 

File *newfile(char *file);
Name *makename(char *string);
Data *savedata(int year, int rank, double usage);
void append_femname(Name *p);
void append_malname(Name *p);
void append_data(Name *p, Data *d);
void append_file(File *p);
Name *search(char *string, Name *head, Name *tail);
void clear(Name *nhead);
void clear_files();


