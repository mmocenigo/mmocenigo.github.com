/* 
Marissa A. Mocenigo
Tuesday, April 21, 2009

Saves search name and filenames (if applicable)

*/


#include "main.h"
#include "llist.h"
#include "extern.h"


int
process(int argc, char *argv[]) {
  int done = 0, len;
  int success = 1;
  char *progname;
  File *f;
  
  progname = *argv++;
  while (!done && --argc > 0) {
    switch(argv[0][0]) {
    case '-':
      switch(argv[0][1]) {
      case 'h': //Only Flag Implemented
	hist = TRUE;
	if (argv[0][2] == '\0') {
	  if (--argc > 0) {
	    strcpy(strName, (*++argv));
	    argv++;
	    argc--;
	  } else {
	    fprintf(stderr, "ERROR: Name Input is Incorrect\n");
	  }
	} else {
	  strcpy(strName, (&argv[0][2]));
	}
	break;
    default:
      fprintf(stderr, "ERROR: Encountered an Unrecognized Flag\n");
      success = 0;
      break;
      }
   default: //Indicates end of Flags
    done = 1;
    break;
    }
    if (done != 1) {
      argv++;
    }
  }
  if (argc > 0) {
    for (fcnt = 0; fcnt < argc; fcnt++) {
      len = strlen(argv[fcnt]); //All name files are same length, but we must take directory into account, which should be same for all as well
      if (len < 10) {
	f = newfile(argv[fcnt]);
	append_file(f);
		 //strcpy(files[fcnt], argv[fcnt]);
      } else {
      fprintf(stderr, "ERROR: File Name Too Long");
      }
    }
  } else {
    fcnt = 0;
      }
  return (success);
}
