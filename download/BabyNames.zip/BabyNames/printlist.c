/* 
Marissa A. Mocenigo
Tuesday, April 21, 2009

The largest number of babies is printed 60 spaces from the year and each subsequent usage number is scaled based on this largest number.

*/


#include "main.h"
#include "llist.h"
#include "extern.h"

void printllist() {
  int i;
  Name *tmp;
  Data *temp;
  double max_spaces = 60;
  double val;
  double fract;
  int spaces;


  if ((tmp = search(strName, fhead, ftail)) != NULL) {
    printf("%s (FEMALE):\n", strName);
    val = tmp->largest; //Largest usage of name
    for (temp = tmp->head; temp != NULL; temp = temp->next) {
      if (temp->year != 0) { //IF NOT read from stdin (namely, there is year data)
	fract = (temp->usage)/(val); //Fraction of largest spacing
	spaces = (int) (fract * max_spaces); //Number spaces
	printf("%d ", temp->year); //Year
	for (i = 0; i < spaces; i++) {
	  printf(" ");
	}
	printf("%.0f\n", temp->usage);
      } else { //If read from stdin (no differentiation between years)
	printf("TOTAL: "); //Total, as years unknown
	for (i = 0; i < 60; i++) {
	  printf(" ");
	}
	printf("%.0f\n\n", temp->usage); //Only one node is saved from stdin
      }
    }
  } else {
    fprintf(stderr, "ERROR: Name, %s, Not Found in Female Names\n", strName);
  }


  printf("\n\n");

  //Same as above, but for male names
  
  if ((tmp = search(strName, mhead, mtail)) != NULL) {
    printf("%s (MALE):\n", strName);
    val = tmp->largest;
    for (temp = tmp->head; temp != NULL; temp = temp->next) {
      if (temp->year != 0) {
	fract = (temp->usage)/(val);
	spaces = (int) (fract * max_spaces);
	printf("%d ", temp->year);
	for (i = 0; i < spaces; i++) {
	  printf(" ");
	}
	printf("%.0f\n", temp->usage);
      } else {
	printf("TOTAL: ");
	for (i = 0; i < 60; i++) {
	  printf(" ");
	}
	printf("%.0f\n\n", temp->usage);
      }
    }
  } else {
    fprintf(stderr, "ERROR: Name, %s, Not Found in Male Names\n", strName);
  }
}
  

