/* 
Marissa A. Mocenigo
Tuesday, April 21, 2009

Small functions to deal with various nodes within the 3 different linked lists.

*/


#include "main.h"
#include "llist.h"
#include "extern.h"


File 
*newfile(char *file) {
  File *new;
  if ( (new = (File *) malloc (sizeof(File) ) ) != NULL) {
    if (strlen(file) > 10) {
      fprintf(stderr, "ERROR: File, %s, Name Too Long\n", file);
    } else {
      strcpy(new->filename, file);
      new->next = NULL;
    }
  } else {
    fprintf(stderr, "Linked List (File): Out of Memory\n");
    exit(0);
  }
    return new;
}

Name 
*makename(char *string) {
  Name *new;
  if ( (new = (Name *) malloc (sizeof(Name) ) ) != NULL) {
    if (strlen(string) > 20) {
      fprintf(stderr, "ERROR: Name Too Long\n");
    } else {
    strcpy(new->name, string);
    new->largest = 0;
    new->next = NULL;
    new->head = NULL;
    new->tail = NULL;
    }
  }

  else {
    fprintf(stderr, "Linked List (Name): Out of Memory\n");
    exit(0);

  }
  return new;
}

Data
*savedata(int year, int rank, double usage) {
  Data *new;
  if ( (new = (Data *) malloc(sizeof(Data))) != NULL ) {
    new->year = year;
    new->rank = rank;
    new->usage = usage;
    new->next = NULL;
  }
  else {
    fprintf(stderr, "Linked List (Data): Out of Memory\n");
  }
  return new;
}

void 
append_femname(Name *p) {
  if (fhead == NULL) {
    fhead = p;
    ftail = p;
  }
  else {
    ftail->next = p;
    ftail = p;
  }
}

void 
append_malname(Name *p) {
  if (mhead == NULL) {
    mhead = p;
    mtail = p;
  }
  else {
    mtail->next = p;
    mtail = p;
  }
}

void
append_data(Name *p, Data *d) {
  if (p->head == NULL) {
    p->head = d;
    p->tail = d;
  }
  else {
    p->tail->next = d;
    p->tail = d;
  }
  if (d->usage > p->largest) { //Keep track for spacing in histogram
    p->largest = d->usage;
  }
}

void
append_file(File *p) {
  if (file_head == NULL) {
    file_head = p;
    file_tail = p;
  } else {
    file_tail->next = p;
    file_tail = p;
  }
}


void
clear(Name *nhead) {
  Name *tmp, *tmp2;
  Data *temp, *temp2;
  for (tmp = nhead; tmp != NULL; tmp = tmp2) {
    for (temp = tmp->head; temp != NULL; temp = temp2) {
      temp2 = temp->next;
      free(temp);
    }
    tmp2 = tmp->next;
    free(tmp);
  }
}

void
clear_files() {
  File *temp, *temp2;
  for (temp = file_head; temp != NULL; temp = temp2) {
      temp2 = temp->next;
      free(temp);
  }
}

Name *
search(char *string, Name *head, Name *tail) {
  Name *tmp;
  for (tmp = head; tmp != NULL; tmp = tmp->next) {
    if (strcmp(tmp->name, string) == 0) {
      return tmp;
    }
  }
    return NULL;
}
