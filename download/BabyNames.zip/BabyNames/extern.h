/* 
Marissa A. Mocenigo
Tuesday, April 21, 2009

This file declares non-linked list functions and global variables.


 */


extern Name *mhead; //Male Name List
extern Name *fhead; //Female Name List
extern Name *mtail;
extern Name *ftail;
extern File *file_head; //File Linked List
extern File *file_tail;
extern char strName[40];
extern int hist; //Histogram Flag, Only Flag Implemented
extern int fcnt; //Number of Files

void get_data(FILE *fp, int year);
int process(int argc, char *argv[]);
void printllist();
int getYearFromName(char *name);
