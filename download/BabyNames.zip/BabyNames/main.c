/* 
Marissa A. Mocenigo
Tuesday, April 21, 2009

Overall, this program accepts input in the following format:
[EXECUTABLE] -h [NAME] [FILES -opt]

If no files are entered, the program reads data from stdin.

Ultimately, it catalogues the data into linked lists and prints out the usage in a histogram for the name being searched.

*/


#include "main.h"
#include "llist.h"
#include "extern.h"

Name *mhead;
Name *fhead;
Name *mtail;
Name *ftail;
File *file_head;
File *file_tail;
char files[18][10];
char strName[40];
int hist;
int fcnt;


int
main(int argc, char *argv[]) {
  FILE *fp;
  File *fileobj;
  int success;
  int year;

  success = process(argc, argv);
  if (fcnt > 0) {
    for (fileobj = file_head; fileobj != NULL; fileobj = fileobj->next) {
      if ((fp = fopen(fileobj->filename, "r")) != NULL) {
	year = getYearFromName(fileobj->filename);
	get_data(fp, year);
      } else {
	fprintf(stderr, "ERROR: Could Not Read File: %s\n", fileobj->filename);
      }
    }
  } else {
      year = 0000;
      get_data(stdin, year);
  }

  if (hist == TRUE) {
    printllist();
  } else {
    fprintf(stderr, "ERROR: Incorrect Command Line Entry. Please Include -h Flag\n");
  }
  clear(fhead);
  clear(mhead);
  clear_files();
 
  return 0;
}
