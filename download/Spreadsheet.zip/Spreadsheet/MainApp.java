/**
 * @author Marissa Mocenigo
 * May 4, 2010
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.text.*;
import java.util.*;
import javax.swing.table.DefaultTableModel;

/**
 * Spreadsheet class extends JFrame
 * Each instantiation creates a new spreadsheet window
 * Size is based on user specification
*/
public class
Spreadsheet extends JFrame {
	char[] alphaLabels = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
	
	
	int selectX; //x-coordinate of currently selected cell
	int selectY; //y-coordinate of currently selected cell
	
	int width = 0; //width of spreadsheet
	int height = 0; //height of spreadsheet
	
	JTextField wide;
	JTextField high;
	
	JTextField input;
	
	DefaultTableModel model;
	JTable table;
	
	String[][] cellData;
	
	String[] colNames;
	
	String inputData;
	
/**
 * Spreadsheet Constructor
*/
public Spreadsheet() {
	get_width_and_height(); //will not continue until width and height are obtained

	
	colNames = new String[width+1];
	
	for (int i = 0; i < (width+1); i++) {
		colNames[i] = ""; //Column names are included in cell data
	}
	
	model = new DefaultTableModel((height+1), (width+1)) {
		// Override method -- I do not want user double-clicking to change cell contents
		public boolean isCellEditable(int row, int column) {
			return false;
		}
	}; // Need to take label space into account
	
	createEmptySpreadsheet(height, width); //fills cellData with column/row headers and empty cells
	model.setDataVector(cellData, colNames);
	

	table = new JTable(model);
	table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); //want to use the JLabel's preferred size
    table.setDefaultRenderer(table.getColumnClass(0), new JLabelRenderer()); //All are the same columnClass
    table.setCellSelectionEnabled(true);
    table.addMouseListener(new MouseAdapter()
	{
    	public void mouseClicked(MouseEvent e)
    	{
            Point p = e.getPoint();
            int r = table.rowAtPoint(p);
            int c = table.columnAtPoint(p);
            table.clearSelection(); // no other cells are selected
            selectX = r;
            selectY = c;
            if (selectX != 0 && selectY != 0) { //cannot select this empty cell
            	Object val = model.getValueAt(r, c);
            	input.setText(val.toString());
            } else {
            	input.setText("");
            }

            table.changeSelection(r, c, true, false);
            table.changeSelection(0, c, true, false);
            table.changeSelection(r, 0, true, false);
            Thread.yield();
            table.repaint(); //refreshes cell values
			
    	}
	});
	
	JScrollPane scroller = new JScrollPane(table);
	scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS); //personal preference
	scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); //personal preference
	
	input = new JTextField();
	input.addKeyListener(new KeyListener() {
		public void keyTyped(KeyEvent e1) {
		}
		
		public void keyPressed(KeyEvent e2) {
		}
		
		public void keyReleased(KeyEvent e3) {
			if (e3.getKeyCode() == KeyEvent.VK_ENTER) { //the enter key finalizes the input
				if (selectX != 0 && selectY != 0) {
					model.setValueAt(input.getText(), selectX, selectY);
				}
			}
		}
		
	});
	
	
	this.getContentPane().setLayout(new BorderLayout());
	this.add(input, BorderLayout.NORTH);
	this.add(scroller, BorderLayout.CENTER);
	
	this.setTitle("Spreadsheet Application");
	this.setLocationRelativeTo(null); //center the window
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setSize(600,400);
	this.setVisible(true);
	
}

/**
 * Creates dialogue box to obtain size of spreadsheet 
*/
public void get_width_and_height() {
	final JDialog prompt = new JDialog();
	
	JLabel W = new JLabel("Please enter the width of the spreadsheet:");
	JLabel H = new JLabel("Please enter the height of the spreadsheet:");
	JButton ok = new JButton("OK");
	wide = new JTextField();
	high = new JTextField();
	
	ok.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			try {
				width = Integer.parseInt(wide.getText());
				height = Integer.parseInt(high.getText());
				if (width > 0 && height > 0) { //do not continue until a relevant value is entered
					prompt.setVisible(false);
				}
			} catch(NumberFormatException num) {
		
			}
		}
	});
		
		
	JPanel inputPanel = new JPanel();
	inputPanel.setLayout(new GridLayout(2,2));
	inputPanel.add(W);
	inputPanel.add(wide);
	inputPanel.add(H);
	inputPanel.add(high);
	
	prompt.setModal(true); //do not continue
	
	prompt.getContentPane().setLayout(new BorderLayout());
	prompt.add(inputPanel, BorderLayout.CENTER);
	prompt.add(ok, BorderLayout.SOUTH);
	
	prompt.setLocationRelativeTo(null);
	prompt.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	prompt.setSize(600,100);
	prompt.setVisible(true);
	
}



/**
 * Takes a string and converts it to its corresponding index in the spreadsheet
 * @param a The string to be converted
 * @return result The integer result of the converted string
*/	
public int alphaToInt(String a) {
	int len = a.length();
	int result = 0;
	
	for (int i = 0; i < len; i++) {
		for (int j = 0; j < alphaLabels.length; j++) {
			if (a.charAt(i) == alphaLabels[j]) {
				result += (j + (i*26));
			}
		}
	}
	
	return result;
}

/**
 * Reverse of alphaToInt -- takes an integer and converts it to the String index
 * @param i The integer to be converted
 * @return (alpha+alphaLabels[i])
*/
public String intToAlpha(int i) {
	String alpha = "";
	int rem;
	
	if (i >= 26) {
		return intToAlpha((i/26)-1) + intToAlpha(i%26);
	} else {
		return (alpha + alphaLabels[i]);
	}
		
}

/**
 * Creates an empty data set based on the size requested by the user
 * @param h the height of the spreadsheet
 * @param w the width of the spreadsheet
*/
public void createEmptySpreadsheet(int h, int w) {

	cellData = new String[(w+1)][(h+1)]; //need to take headers into account
	
	for (int i = 0; i < (h+1); i++) {
		for (int j = 0; j < (w+1); j++) {
			switch (i) {
				case 0:
					if (j != 0) {
						cellData[j][i] = intToAlpha(j-1); //subtract one to take headers into account
					} else {
						cellData[j][i] = "";
					}
					break;
				default:
					switch (j) {
						case 0:
							cellData[j][i] = Integer.toString(i);
							break;
						default:
							cellData[j][i] = "";
							break;
							
						}
						break;
			}
		}
	}		

}

public static void main(String[] args) {
	Spreadsheet Spreadsheet = new Spreadsheet();
	
}

}