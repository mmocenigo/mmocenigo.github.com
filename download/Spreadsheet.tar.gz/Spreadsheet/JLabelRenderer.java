import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;

/**
 * @author Marissa Mocenigo
 * Renders JLabels in a JTable
*/
public class
JLabelRenderer extends JLabel implements TableCellRenderer {

	Dimension size;
	int cellWidth = 100;
	int cellHeight = 20;
	char[] alphaLabels = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
	//alphaLabels is sort of redundant but I have it here for the intToAlpha/alphaToInt functions
	
/**
 * Renderer constructor
*/
public JLabelRenderer() {

	this.size = new Dimension(cellWidth, cellHeight);
	this.setPreferredSize(size);
	this.setBorder(BorderFactory.createLineBorder(Color.black)); //all cells have the same black border
	this.setOpaque(true);
	
}

/**
 * @param table
 * @param value
 * @param isSelected
 * @param hasFocus
 * @param row
 * @param column
*/
public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	String val = value.toString();
	
	if (row == 0 || column == 0) {
		this.setBackground(Color.lightGray); //if a header
	} else {
		this.setBackground(Color.white); //if a data cell
	}
	
	if (isSelected) {
		if (row == 0 && column == 0) {
			this.setBackground(Color.lightGray); //to ensure that the 0,0 cell never APPEARS highlighted
		} else {
			this.setBackground(Color.yellow); //selection is shown by a yellow bckgrnd
		}
	}
	
	val = parseInput(val, table); //interprets data
	
	try {
		float tester = Float.parseFloat(val);
		this.setHorizontalAlignment(JLabel.RIGHT); //align right is a number
	} catch (NumberFormatException n) {
		this.setHorizontalAlignment(JLabel.LEFT); //align left if text
	}
	
	setText(val);
	
	return this;
}

/**
 * Takes a string and converts it to its corresponding index in the spreadsheet
 * @param a The string to be converted
 * @return result The integer result of the converted string
*/	
public int alphaToInt(String a) { //exactly the same as in Spreadsheet.java
	int len = a.length();
	int result = 0;
	
	for (int i = 0; i < len; i++) {
		for (int j = 0; j < alphaLabels.length; j++) {
			if (a.charAt(i) == alphaLabels[j]) {
				result += (j + (i*26));
			}
		}
	}
	
	return result;
}


/**
 * Reverse of alphaToInt -- takes an integer and converts it to the String index
 * @param i The integer to be converted
 * @return (alpha+alphaLabels[i])
*/
public String intToAlpha(int i) { //exactly the same as in Spreadsheet.java
	String alpha = "";
	int rem;
	
	if (i >= 26) {
		return intToAlpha((i/26)-1) + intToAlpha(i%26);
	} else {
		return (alpha + alphaLabels[i]);
	}
		
}

/**
 * Takes the table's values and parses it, if necessary
 * @param val The string value of the cell
 * @param table The table (so as to get the values in other positions)
 * @return val Returns a string of the parsed val
*/
public String parseInput(String val, JTable table) {
	String key = "="; //indicates that the user expects the program to seek the data in another cell
	String start = "";
	String end = "";
	String[] parts = new String[3];
	String result1;
	String result2;
	float res1;
	float res2;
	int r;
	int c;

	if (val.contains(key)) {
		if (val.length() > 2) {
			val = val.substring(1); //remove '=' for evaluation
		} else {
			return "INVALID ADDRESS"; //the address is not 2 characters (alpha)(num)
		}
		if (val.matches("[A-Z]+[0-9]+")) { //JUST another cell address
			for (int i = val.length(); i > 0; i--) {
				start = val.substring(0,i);
					if (start.matches("[A-Z]+")) {
						end = val.substring(i, val.length());
					}
				}
				r = alphaToInt(start)+1;
				c = Integer.parseInt(end);
				if (c < table.getColumnCount() && r < table.getRowCount()) {
					return (table.getValueAt(r, c)).toString();
				} else {
					return "INVALID ADDRESS";
				}
			}
		if (val.matches("[A-Z]+[0-9]+[+].*")) {
			for (int i = 0; i < val.length(); i++) {
				if (val.charAt(i) == '+') {
					start = val.substring(0,i);
					end = val.substring((i+1), val.length());
					break;
				}
			}
			result1 = parseInput(key+start, table);
			result2 = parseInput(key+end, table);
			try { //only numbers can have the +, -, *, or / operand
				res1 = Float.parseFloat(result1);
				res2 = Float.parseFloat(result2);
				return Float.toString(res1+res2);
			} catch (NumberFormatException e) {
				return "INVALID INPUT";
			}
		}
		if (val.matches("[A-Z]+[0-9]+[-].*")) {
			System.out.println(".");
			for (int i = 0; i < val.length(); i++) {
				if (val.charAt(i) == '-') {
					start = val.substring(0,i);
					end = val.substring((i+1), val.length());
					break;
				}
			}
			result1 = parseInput(key+start, table);
			result2 = parseInput(key+end, table);
			try {
				res1 = Float.parseFloat(result1);
				res2 = Float.parseFloat(result2);
				return Float.toString(res1-res2);
			} catch (NumberFormatException e) {
				return "INVALID INPUT";
			}
		}
		if (val.matches("[A-Z]+[0-9]+[*].*")) {
			for (int i = 0; i < val.length(); i++) {
				if (val.charAt(i) == '*') {
					start = val.substring(0,i);
					end = val.substring((i+1), val.length());
					break;
				}
			}
			result1 = parseInput(key+start, table);
			result2 = parseInput(key+end, table);
			try {
				res1 = Float.parseFloat(result1);
				res2 = Float.parseFloat(result2);
				return Float.toString(res1*res2);
			} catch (NumberFormatException e) {
				return "INVALID INPUT";
			}
		}
		if (val.matches("[A-Z]+[0-9]+[/].*")) {
			for (int i = 0; i < val.length(); i++) {
				if (val.charAt(i) == '/') {
					start = val.substring(0,i);
					end = val.substring((i+1), val.length());
					break;
				}
			}
			result1 = parseInput(key+start, table);
			result2 = parseInput(key+end, table);
			try {
				res1 = Float.parseFloat(result1);
				res2 = Float.parseFloat(result2);
				return Float.toString(res1/res2);
			} catch (NumberFormatException e) {
				return "INVALID INPUT";
			}
		}
	}
		
		return val; //otherwise, parsing is unnecessary
	

}

}