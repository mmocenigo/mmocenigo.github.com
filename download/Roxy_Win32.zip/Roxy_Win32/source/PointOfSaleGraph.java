import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import javax.swing.JFrame; 
import controlP5.*; 
import java.util.Set; 
import java.util.*; 
import java.util.*; 
import java.lang.Math; 
import java.util.Calendar; 
import java.util.Date; 
import java.text.SimpleDateFormat; 
import java.util.Date; 
import java.text.SimpleDateFormat; 
import java.text.ParseException; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class PointOfSaleGraph extends PApplet {

/*
* Author: Marissa Mocenigo
* Date: January 2013
* This is the main class of the POS analysis tool.
*/

/*
COLORS FROM ROXY'S CSS:
Blue: #1BAACC
Brownish Header: #948A6A
Brown: #513625
Pale yellow: ede7c5

*/

ControlPanelFrame panel_;
Graph graph_ = null;
CsvData csvData_;

static int AXIS_PADDING = 75;

public void setup() {
  frame.setTitle("Graph");
  // Size is relative to screen size
  size((displayWidth/4) * 3, (displayHeight/4) * 3);
  panel_ = new ControlPanelFrame();
}

public void draw() {
  // Redraw to clear previous frame
   drawBorder();
   // Only draw graph when it's instantiated
   if (graph_ != null) {
     graph_.plotData();
   }
}
  
public void drawBorder() {
  // Draws 'out of bounds' graph regions
  stroke(0xffe7e7e7);
  strokeWeight(0);
  fill(0xffe7e7e7);
  rect(0, 0, AXIS_PADDING, height);
  rect(0, height - AXIS_PADDING, width, AXIS_PADDING);
  // Draws the background for the main graph region
  stroke(255);
  strokeWeight(0);
  fill(255);
  rect(AXIS_PADDING, 0, width - AXIS_PADDING, height - AXIS_PADDING);
  // Draws the axes
  stroke(0xff808080);
  strokeWeight(1.5f);
  line(AXIS_PADDING, 0, AXIS_PADDING, height);
  line(0, height - AXIS_PADDING, width, height - AXIS_PADDING);
}


public void mousePressed() {
  if (graph_ != null) {
    graph_.mousePressed();
  }
}

public void mouseDragged() {
  if (graph_ != null) {
    graph_.mouseDragged();
  }
}

public void mouseReleased() {
    if (graph_ != null) {
   graph_.mouseReleased();
  }
}

public void keyPressed() {
    if (graph_ != null) {
   graph_.keyPressed();
  }
}  





public class ControlPanelFrame extends JFrame {
  ControlPanelApplet applet_;
  
  public ControlPanelFrame() {
    setBounds(50,50,400,400);
    applet_ = new ControlPanelApplet();
    add(applet_);
    applet_.init();
    setDefaultCloseOperation( JFrame.HIDE_ON_CLOSE );
    setResizable(false);
    show();
  }
}

public class ControlPanelApplet extends PApplet {
  String filePath_;
  ControlP5 cp5_;
  Accordion accordion_;
  Group importOptionPanel_;
  Group customGraphPanel_;
  Group presetGraphPanel_;
  Textfield filepathField_;
  Textarea importStatus_;
  RadioButton customBestFitOption_;
  DropdownList xOptions_, yOptions_;
  int panelWidth_;
  int panelHeight_;
  int panelMargin_;
  int numberOfPanels_;
  int contentsWidth_;
  int contentsHeight_;
  int fontSize_;
  int lineHeight_;
  PFont font_;
    
  public void setup() {
    filePath_ = "";
    panelWidth_ = 400;
    panelHeight_ = 400;
    panelMargin_ = 20;
    numberOfPanels_ = 3;
    contentsWidth_ = panelWidth_ - 2*panelMargin_;
    contentsHeight_ = panelHeight_ - 2*panelMargin_;
    fontSize_ = 15;
    lineHeight_ = fontSize_ * 2;
    size(panelWidth_, panelHeight_);
    cp5_ = new ControlP5(this);
    cp5_.setColorBackground(0xffbfb28a);
    cp5_.setColorForeground(0xff1BAACC);
    cp5_.setColorCaptionLabel(0xffFFFFFF);
    cp5_.setColorActive(0xff1BAACC);
    guiSetup();
  }
    
  public void draw() {
    background(0xffedde89);
  }
    
  protected void guiSetup() {
    font_ = createFont("Helvetica", fontSize_);
    cp5_.setControlFont(font_);
    buildImportControls();
    buildCustomGraphControls();
    buildPresetGraphControls();
    accordion_ = cp5_.addAccordion("accordion")
      .setBarHeight(lineHeight_)
      .setPosition(panelMargin_ , panelMargin_)
      .setSize(contentsWidth_, contentsHeight_)
      .addItem(importOptionPanel_)
      .addItem(customGraphPanel_)
      .addItem(presetGraphPanel_);
     customGraphPanel_.disableCollapse();
     presetGraphPanel_.disableCollapse();
     accordion_.open(0);
     accordion_.setCollapseMode(Accordion.SINGLE); 
  }
    
  protected void buildImportControls() {
    int padding = 10;
    int widgetHeight = contentsHeight_ - numberOfPanels_*lineHeight_ - 2*panelMargin_;
    importOptionPanel_ = cp5_.addGroup("Import Options")
      .setSize(contentsWidth_, widgetHeight)
      .setBackgroundColor(0xfff9f3d1)
      .setBackgroundHeight(widgetHeight)
      .setPosition(panelMargin_, panelMargin_)
      .setBarHeight(lineHeight_);
      
    importOptionPanel_.getCaptionLabel().toUpperCase(false).align(ControlP5.LEFT, ControlP5.CENTER);
      
      
    filepathField_ = cp5_.addTextfield("filepath")
      .setCaptionLabel("")
      .setPosition(padding, padding)
      .setSize(3*(contentsWidth_ - 3*padding)/4, lineHeight_)
      .moveTo(importOptionPanel_);
      
    cp5_.addButton("browseButton")
      .setCaptionLabel("Browse")
      .setPosition(3*(contentsWidth_ - 3*padding)/4 + 2*padding, padding)
      .setSize((contentsWidth_ - 3*padding)/4, lineHeight_)
      .moveTo(importOptionPanel_)
      .activateBy(ControlP5.RELEASE)
      .getCaptionLabel().toUpperCase(false).align(ControlP5.CENTER, ControlP5.CENTER);
      
    cp5_.addButton("importButton")
      .setCaptionLabel("Import File")
      .setPosition(padding, 2*padding + lineHeight_)
      .setSize((contentsWidth_ - 3*padding)/3, lineHeight_)
      .moveTo(importOptionPanel_)
      .activateBy(ControlP5.RELEASE)
      .getCaptionLabel().toUpperCase(false).align(ControlP5.CENTER, ControlP5.CENTER);
      
    cp5_.addButton("clearImportButton")
      .setCaptionLabel("Clear Import")
      .setPosition(2* padding + (contentsWidth_ - 3*padding)/3, 2*padding + lineHeight_)
      .setSize((contentsWidth_ - 3*padding)/3, lineHeight_)
      .moveTo(importOptionPanel_)
      .activateBy(ControlP5.RELEASE)
      .getCaptionLabel().toUpperCase(false).align(ControlP5.CENTER, ControlP5.CENTER);
      
    importStatus_ = cp5_.addTextarea("Import Status")
      .setPosition(padding, 3*padding + 2*lineHeight_)
      .setSize(contentsWidth_ - padding, contentsHeight_ - 3*padding + 2*lineHeight_)
      .setText("No File Imported.")
      .setColor(color(0xff513625))
      .moveTo(importOptionPanel_);
      
  }
     
  protected void buildCustomGraphControls() {
    int padding = 10;
    int widgetHeight = contentsHeight_ - numberOfPanels_*lineHeight_ - 2*panelMargin_;
    customGraphPanel_ = cp5_.addGroup("Custom Graph Settings")
      .setSize(contentsWidth_, widgetHeight)
      .setBackgroundColor(0xfff9f3d1)
      .setBarHeight(lineHeight_);
      
    customGraphPanel_.getCaptionLabel().toUpperCase(false).align(ControlP5.LEFT, ControlP5.CENTER);
      
    xOptions_ = cp5_.addDropdownList("X-Axis")
      .setPosition(padding, padding*4)
      .setBarHeight(lineHeight_)
      .setItemHeight(lineHeight_)
      .setSize(contentsWidth_ - 2*padding, lineHeight_)
      .moveTo(customGraphPanel_);
      
    xOptions_.getCaptionLabel().toUpperCase(false).align(ControlP5.LEFT, ControlP5.CENTER);
    xOptions_.setHeight(lineHeight_ * 6);
      
    yOptions_ = cp5_.addDropdownList("Y-Axis")
      .setPosition(padding, padding*5 + lineHeight_)
      .setBarHeight(lineHeight_)
      .setItemHeight(lineHeight_)
      .setSize(contentsWidth_ - 2*padding, lineHeight_)
      .moveTo(customGraphPanel_);
    
    yOptions_.getCaptionLabel().toUpperCase(false).align(ControlP5.LEFT, ControlP5.CENTER);
    yOptions_.setHeight(lineHeight_ * 6);
      
    customBestFitOption_ = cp5_.addRadioButton("customBestFit")
      .setPosition(padding, padding*6 + lineHeight_)
      .setSize(lineHeight_, lineHeight_)
      .setColorForeground(color(0xffFFFFFF))
      .setColorBackground(color(0xffbfb28a))
      .setColorActive(color(0xff1BAACC))
      .setColorLabel(color(0xff513625))
      .addItem("Show Best Fit", 0)
      .moveTo(customGraphPanel_);
      
    for(Toggle t:customBestFitOption_.getItems()) {
      t.captionLabel().style().backgroundWidth = contentsWidth_ - 3*padding - lineHeight_;
      t.captionLabel().style().backgroundHeight = lineHeight_;
      t.captionLabel().toUpperCase(false);
    }
     
    cp5_.addButton("drawCustomGraphButton")
      .setCaptionLabel("Draw Graph")
      .setPosition(contentsWidth_ - (padding + contentsWidth_/4), widgetHeight - (padding + lineHeight_))
      .setSize(contentsWidth_/4, lineHeight_)
      .moveTo(customGraphPanel_)
      .activateBy(ControlP5.RELEASE)
      .getCaptionLabel().toUpperCase(false).align(ControlP5.CENTER, ControlP5.CENTER)
    ;
      
    yOptions_.bringToFront();
    xOptions_.bringToFront();
  }
     
  protected void buildPresetGraphControls() {
    int padding = 10;
    int widgetHeight = contentsHeight_ - numberOfPanels_*lineHeight_ - 2*panelMargin_;
    presetGraphPanel_ = cp5_.addGroup("Preset Graph Settings")
      .setSize(contentsWidth_, widgetHeight)
      .setBackgroundColor(0xfff9f3d1)
      .setBarHeight(lineHeight_);
      presetGraphPanel_.getCaptionLabel().toUpperCase(false).align(ControlP5.LEFT, ControlP5.CENTER);
     }
     
  public void browseButton() {
    selectInput("Choose a CSV File for Import", "fileSelected");
   }
     
   public void fileSelected(java.io.File selection) {
     if (selection == null) {
       importStatus_.setText("No file selected or file is unreadable.");
     } else {
       filePath_ = selection.getAbsolutePath();
       if (filePath_.endsWith(".csv")) {
         filepathField_.setText(filePath_);
       } else {
         importStatus_.setText("File selected does not match CSV format.");
         filePath_ = "";
       }
    }
  }
     
  public void importButton() {
    if (filePath_ != "") {
      CsvParser dataParser = new CsvParser(filePath_);
      csvData_ = dataParser.getCsvDataFromFile();
      setXAxisOptions(csvData_.getAvailableXHeaders());
      setYAxisOptions(csvData_.getAvailableYHeaders());
      customGraphPanel_.enableCollapse();
      if (filePath_.contains("/")) {
        importStatus_.setText("Reading from file:\n " + filePath_.substring(filePath_.lastIndexOf("/"), filePath_.length()));
      } else {
        importStatus_.setText("Reading from file:\n " + filePath_);
      }
      accordion_.close(0);
      accordion_.open(1);
      filepathField_.setText("");
    }
  }
    
  public void clearImportButton() {
    csvData_ = null;
    graph_ = null;
    filepathField_.setText("");
    filePath_ = "";
    importStatus_.setText("No File Imported.");
    xOptions_.clear();
    yOptions_.clear();
    customBestFitOption_.deactivate(0);
    customGraphPanel_.disableCollapse();
  }
    
  public void setXAxisOptions(ArrayList<String> strings) {
    xOptions_.clear();
    for (int x = 0; x < strings.size(); x++) {
      xOptions_.addItem(strings.get(x), x);
    }
  }
     
  public void setYAxisOptions(ArrayList<String> strings) {
    yOptions_.clear();
    for (int y = 0; y < strings.size(); y++) {
      yOptions_.addItem(strings.get(y), y);
    }
  }
     
  public boolean getCustomBestFit() {
    return customBestFitOption_.getState(0);
  }
     
  public String getXAxisHeader() {
    return xOptions_.getCaptionLabel().getText();
  }
     
  public String getYAxisHeader() {
    return yOptions_.getCaptionLabel().getText();
  }
     
  public void drawCustomGraphButton() {
    graph_ = new CustomGraph(csvData_.getGraphPoints(getXAxisHeader(), getYAxisHeader()), getXAxisHeader(), getYAxisHeader());
    ((CustomGraph)graph_).setBestFit(getCustomBestFit());
  }
}

/*
* Author: Marissa Mocenigo
* Date: January 2013
* This processes and stores the data when directly parsed from the CSV file
*/




public class CsvData {
 HashMap dataTypes_;
 ArrayList<String[]> rawDataStrings_;
 
 public CsvData() {
   dataTypes_ = new HashMap();
   rawDataStrings_ = new ArrayList<String[]>();
 }
 
 public void setDataTypes(HashMap dataTypes) {
   dataTypes_ = dataTypes;
 }
 
 public void setRawData(ArrayList<String[]> rawData) {
   rawDataStrings_ = rawData;
 }
 
 public ArrayList<String> getAvailableXHeaders() {
   ArrayList<String> xHeaders = new ArrayList<String>();
   Iterator headerIter = dataTypes_.entrySet().iterator();
   while (headerIter.hasNext()) {
     Map.Entry headerPair = (Map.Entry)headerIter.next();
     String header = (String)headerPair.getKey();
     int stringIndex = (Integer)(headerPair.getValue());
     if (DataTools.isDataReadable(((String[])rawDataStrings_.get(0))[stringIndex])) {
       xHeaders.add(header);
     }
   }
   return xHeaders;
 }
 
  public ArrayList<String> getAvailableYHeaders() {
   ArrayList<String> yHeaders = new ArrayList<String>();
   Iterator headerIter = dataTypes_.entrySet().iterator();
   while (headerIter.hasNext()) {
     Map.Entry headerPair = (Map.Entry)headerIter.next();
     String header = (String)headerPair.getKey();
     int stringIndex = (Integer)(headerPair.getValue());
     if (DataTools.isDataReadable(((String[])rawDataStrings_.get(0))[stringIndex])) {
       yHeaders.add(header);
     }
   }
   return yHeaders;
 }
 
 public ArrayList<String> getAllHeaders() {
  return new ArrayList<String>();
 }
 
 public boolean headerExists(String header) {
     Set<String> dataStrings = dataTypes_.keySet();
     return dataStrings.contains(header);
 }
 
 public ArrayList getGraphPoints(String xString, String yString) {
   ArrayList dataPoints = new ArrayList();
   int xIndex = (Integer)dataTypes_.get(xString);
   int yIndex = (Integer)dataTypes_.get(yString);
   
   for (int i = 0; i < rawDataStrings_.size(); i++) {
     String xValue = rawDataStrings_.get(i)[xIndex];
     String yValue = rawDataStrings_.get(i)[yIndex];
     
     dataPoints.add(new GraphPoint(xValue, yValue));
   }
   return dataPoints;
 }
 
  
}
/*
* Author: Marissa Mocenigo
* Date: January 2013
* This class strictly opens and reads the CSV file and creates CSV data from the content
*/

public class CsvParser {
  String csvFilePath_;
  
  public CsvParser(String csvFilePath) {
    csvFilePath_ = csvFilePath;
  }
  
  public CsvData getCsvDataFromFile() {
    CsvData data = new CsvData();
    data.setDataTypes(getHeaderDataFromFile());
    data.setRawData(getRawDataFromFile());
    return data;
  }
  
  private HashMap getHeaderDataFromFile() {
    BufferedReader reader = createReader(csvFilePath_);
    try {
      String headerLine = reader.readLine();
      return mapHeaderToColumnIndex(headerLine);
    } catch (IOException e) {
      System.err.println("Header data could not be parsed from .csv file at " + csvFilePath_);
    }
    return new HashMap();
  }
  
  private ArrayList<String[]> getRawDataFromFile() {
    ArrayList<String[]> rawData = new ArrayList<String[]>();
    BufferedReader reader = createReader(csvFilePath_);
    try {
      String headerLine = reader.readLine();
      HashMap indexToColumnName = mapHeaderToColumnIndex(headerLine);
      for (String line = reader.readLine(); line != null; line = reader.readLine()) {
        line = replaceCharsInSubString(line);
        String[] tokens = split(line, ",");
        rawData.add(tokens);
      }
    } catch (IOException e) {
      System.err.println("Header data could not be parsed from .csv file at " + csvFilePath_);
    }
    return rawData;
  }
  
  private HashMap mapHeaderToColumnIndex(String headerLine) {
    String[] tokens = splitTokens(headerLine, ",");
    HashMap columns = new HashMap();
    for (int i = 0; i < tokens.length; i++) {
      columns.put(tokens[i], i);
    }
    return columns;
  }
  
  private String replaceCharsInSubString(String subString) {
    StringBuilder modString = new StringBuilder(subString);
    ArrayList indicesToDelete = new ArrayList();
    for (int i = 0; i < subString.length(); i++) {
      int startingIndex = i;
      if (subString.charAt(i) == '"') {
        indicesToDelete.add(i);
        i++;
        while ((subString.charAt(i) != '"') && (i < subString.length())) {
          if (subString.charAt(i) == ',') {
            indicesToDelete.add(i);
          }
          i++;
        }
        if (subString.charAt(i) == '"') {
          indicesToDelete.add(i);
        }
      }
    }
    
    for (int x = 0; x < indicesToDelete.size(); x++) {
     modString.deleteCharAt((Integer)indicesToDelete.get(x) - x);
    } 
    
    return modString.toString();
  }
  
}

/*
* Author: Marissa Mocenigo
* Date: January 2013
* This class handles all graphing capabilities for the most generic graph with user-selected options
*/

public class CustomGraph extends Graph {
  boolean showBestFit_;
  float selectionStartX_, selectionStartY_;
  float mouseStartX_, mouseStartY_;
  boolean recalc_;
  
  public CustomGraph(ArrayList data, String xHeader, String yHeader) {
    setDataPoints(data);
    xHeader_ = xHeader;
    yHeader_ = yHeader;
    recalc_ = false;
    calculateHeaderMarkers();
  }
  
  public void plotData() {
    if (recalc_) {
      calculateHeaderMarkers();
    }
    
    axisLabels();
    
    if (showBestFit_) {
      drawBestFit();
    }
    for (int i = 0; i < dataPoints_.size(); i++) {
      GraphPoint data = (GraphPoint)dataPoints_.get(i);
      if (recalc_) {
        data.recalculate();
      }
      data.drawPoint(xMinRange_, xMaxRange_, yMinRange_, yMaxRange_);
    }
    recalc_ = false;
  }
  
  public void setDataPoints(ArrayList dataPoints) {
    for (int i = 0; i < dataPoints.size(); i++) {
      GraphPoint data = (GraphPoint)dataPoints.get(i);
      if (i == 0) {
        xMax_ = data.getX();
        xMin_ = data.getX();
        yMax_ = data.getY();
        yMin_ = data.getY();
      } else {
        float x = data.getX();
        float y = data.getY();
        if (x > xMax_) {
          xMax_ = x;
        }
        if (y > yMax_) {
          yMax_ = y;
        }
        if (x < xMin_) {
          xMin_ = x;
        }
        if (y < yMin_) {
          yMin_ = y;
        }
        
      }
    }
    xMaxRange_ = xMax_;
    yMaxRange_ = yMax_;
    xMinRange_ = xMin_;
    yMinRange_ = yMin_;
    dataPoints_ = dataPoints;
  }
  
  public void setBestFit(boolean display) {
    showBestFit_ = display;
  }
  
  private void drawBestFit() {
    float sumX = 0;
    float sumY = 0;
    float sumX2 = 0;
    float sumXY = 0;
    
    for (int i = 0; i < dataPoints_.size(); i++) {
      GraphPoint data = (GraphPoint)dataPoints_.get(i);
      float scaledX = data.getScaledX(xMin_, xMax_);
      float scaledY = data.getScaledY(yMin_, yMax_);
      sumX += scaledX;
      sumY += scaledY;
      sumX2 += pow(scaledX, 2);
      sumXY += (scaledX * scaledY);
    }
  
    float xMean = sumX/dataPoints_.size();
    float yMean = sumY/dataPoints_.size();
    float slope = (sumXY - sumX * yMean) / (sumX2 - sumX * xMean);
    float yInt = yMean - slope * xMean;
  
    stroke(0xfffee785);
    strokeWeight(5);
    line(AXIS_PADDING, slope*AXIS_PADDING + yInt, width-AXIS_PADDING, slope*(width-AXIS_PADDING) + yInt);
  }
  
  public void mousePressed() {
    mouseStartX_ = mouseX;
    mouseStartY_ = mouseY;
    selectionStartX_ = DataTools.scaleFromProcessingWindow(mouseStartX_, xMinRange_, xMaxRange_, width);
    selectionStartY_ = DataTools.scaleFromProcessingWindow(height - mouseStartY_, yMinRange_, yMaxRange_, height);
    
    if (selectionStartX_ > xMax_) {
      selectionStartX_ = xMax_;
    }
    if (selectionStartX_ < xMin_) {
      selectionStartX_ = xMin_;
    }
    if (selectionStartY_ > yMax_) {
      selectionStartY_ = yMax_;
    }
    if (selectionStartY_ < yMin_) {
      selectionStartY_ = yMin_;
    }
  }
  
  public void mouseDragged() {
    noFill();
    stroke(0xff808080);
    strokeWeight(1);
    float currentMouseX = mouseX;
    float currentMouseY = mouseY;
    rect(mouseStartX_, mouseStartY_, abs(mouseStartX_ - currentMouseX), abs(mouseStartY_ - currentMouseY));
  }
  
  public void mouseReleased() {
    float selectionEndX = DataTools.scaleFromProcessingWindow(mouseX, xMinRange_, xMaxRange_, width);
    float selectionEndY = DataTools.scaleFromProcessingWindow(height - mouseY, yMinRange_, yMaxRange_, height);
    
    if ((selectionEndX != selectionStartX_) && (selectionEndY != selectionStartY_)) {
        
   if (selectionEndX > xMax_) {
      selectionEndX = xMax_;
    }
    if (selectionEndX < xMin_) {
      selectionEndX = xMin_;
    }
    if (selectionEndY > yMax_) {
      selectionEndY = yMax_;
    }
    if (selectionEndY < yMin_) {
      selectionEndY = yMin_;
    }
    
    if (selectionEndX > selectionStartX_) {
      xMaxRange_ = selectionEndX;
      xMinRange_ = selectionStartX_;
      recalc_ = true;
    } else {
      xMinRange_ = selectionEndX;
      xMaxRange_ = selectionStartX_;
      recalc_ = true;
    }
    
    if (selectionEndY > selectionStartY_) {
      yMaxRange_ = selectionEndY;
      yMinRange_ = selectionStartY_;
      recalc_ = true;
    } else {
      yMinRange_ = selectionEndY;
      yMaxRange_ = selectionStartY_;
      recalc_ = true;
    }
    }
  }
  
  public void keyPressed() {
    if (key == ENTER) {
      xMaxRange_ = xMax_;
      xMinRange_ = xMin_;
      yMaxRange_ = yMax_;
      yMinRange_ = yMin_;
      recalc_ = true;
    }
  }
  
}



/*
* Author: Marissa Mocenigo
* Date: January 2013
* Helper methods, etc.
*/

public static class DataTools {
  
 private DataTools() {  
 }
  
 public static boolean isDateValid(String date) {
   return date.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}");
 }
 
 public static boolean isTimeValid(String time) {
   return time.matches("[0-9]{2}:[0-9]{2}:[0-9]{2}");
 }
 
 public static float dayInSec(String date) {
   if (isDateValid(date)) {
     int year = new Integer(date.substring(0, 4));
     int month = new Integer(date.substring(5, 7));

     int day = new Integer(date.substring(8, 10));
     
     Calendar c = Calendar.getInstance();
     c.set(year, month - 1, day);
     return (float)(c.getTimeInMillis()/1000);
   }
   return 0;
 }
 
 public static int daysFrom(String start, String end) {
   if (isDateValid(start) && (isDateValid(end))) {
     int yearStart = new Integer(start.substring(0, 4));
     int monthStart = new Integer(start.substring(5, 7));
     int dayStart = new Integer(start.substring(8, 10));
     int yearEnd = new Integer(end.substring(0, 4));
     int monthEnd = new Integer(end.substring(5, 7));
     int dayEnd = new Integer(end.substring(8, 10));
     
     Calendar startC = Calendar.getInstance();
     startC.set(yearStart, monthStart, dayStart);
     
     Calendar endC = Calendar.getInstance();
     endC.set(yearEnd, monthEnd, dayEnd);
     
     if (startC.getTimeInMillis() > endC.getTimeInMillis()) {
       long diff = startC.getTimeInMillis() - endC.getTimeInMillis();
       return (int)(diff / (1000*24*60*60));
     } else {
       long diff = endC.getTimeInMillis() - startC.getTimeInMillis();
       return (int)(diff / (1000*24*60*60));
     }
   }
   return 0;
 }
 
 public static float timeToSecFromMidnight(String time) {
   if (isTimeValid(time)) {
     String hString = time.substring(0, 2);
     float h = new Float(hString);
     String mString = time.substring(3, 5);
     float m = new Float(mString);
     String sString = time.substring(6, 8);
     float s = new Float(sString);
     return ((h * 60 * 60) + (m * 60) + s);
   }
   return 0;
 }
 
 public static float getTickRangeForNumber(int tickCount, float min, float max) {
    float range = max - min;
    float unroundedTickSize = range/(tickCount - 1);
    float x = ceil((float)Math.log10(unroundedTickSize)-1);
    float pow10x = pow(10, x);
    float roundedTickRange = ceil(unroundedTickSize/pow10x) * pow10x;
   return roundedTickRange;
  }
 
 public static String fromSecToTimeString(float sec) {
   return "";
 }
 
 public static boolean isNumeric(String number) {
   if (number.contains("$")) {
     StringBuilder strippedString = new StringBuilder(number);
     strippedString.deleteCharAt(number.indexOf("$"));
     number = strippedString.toString();
   }
   try {
     Float.parseFloat(number);
     return true;
   } catch (NumberFormatException e) {
     return false;
   }
 }
 
 public static boolean isDataReadable(String data) {
   return (isDateValid(data) || isTimeValid(data) || isNumeric(data));
 }
 
  public static float scaleToProcessingWindow(float data, float dataMin, float dataMax, float windowMax) {
    if (dataMax != dataMin) {
        return (((windowMax - AXIS_PADDING) - AXIS_PADDING) * (data - dataMin))/(dataMax - dataMin) + AXIS_PADDING;
    } else {
      return AXIS_PADDING;
    }
  }
  
    public static float scaleFromProcessingWindow(float data, float dataMin, float dataMax, float windowMax) {
    if (dataMax != dataMin) {
        return ((dataMax - dataMin) * (data - AXIS_PADDING))/((windowMax - AXIS_PADDING) - AXIS_PADDING) + dataMin;
    } else {
      return AXIS_PADDING;
    }
  }
}






/*
* Author: Marissa Mocenigo
* Date: January 2013
* Abstract graph class with general data for ANY graph
*/

public abstract class Graph {
  protected ArrayList dataPoints_;
  protected ArrayList xAxisTickCoordinates_;
  protected ArrayList yAxisTickCoordinates_;
  protected float xMax_, yMax_, xMin_, yMin_;
  protected float xMaxRange_, yMaxRange_, xMinRange_, yMinRange_;
  protected String xHeader_, yHeader_;
  
  public abstract void plotData();
  //abstract void axisLabels();
  public abstract void mousePressed();
  public abstract void mouseDragged();
  public abstract void mouseReleased();
  public abstract void keyPressed();
  
  protected void axisLabels() {
    pushMatrix();
    fill(0xff808080);
    textAlign(CENTER);
    textSize(24);
    text(xHeader_, width/2, height - (AXIS_PADDING/2));
    translate(AXIS_PADDING/2, height/2);
    rotate(radians(-90));
    text(yHeader_, 0, 0);
    popMatrix();
    drawHeaderMarkers();
  }
  
  protected void drawHeaderMarkers() {
    stroke(0xff808080);
    strokeWeight(1.5f);
    for (int x = 0; x < xAxisTickCoordinates_.size(); x++) {
      float xCoord = (Float)xAxisTickCoordinates_.get(x);
      line(xCoord, height - AXIS_PADDING, xCoord, height - AXIS_PADDING + 10);
    }
    for (int y = 0; y < yAxisTickCoordinates_.size(); y++) {
      float yCoord = (Float)yAxisTickCoordinates_.get(y);
      line(AXIS_PADDING, yCoord, AXIS_PADDING - 10, yCoord);
    } 
  }
  
  protected void calculateHeaderMarkers() {
     xAxisTickCoordinates_ = new ArrayList();
     yAxisTickCoordinates_ = new ArrayList();
    if (xHeader_.equals("Date")) {
      xAxisTickCoordinates_ = calculateTickMarksForXAxisDate();
    }
    if (xHeader_.equals("Time")) {
      xAxisTickCoordinates_ = calculateTickMarksForXAxisTime();
    }
    if (yHeader_.equals("Date")) {
      yAxisTickCoordinates_ = caluclateTickMarksForYAxisDate();
    }
    if (yHeader_.equals("Time")) {
      yAxisTickCoordinates_ = calculateTickMarksForYAxisTime();
    }
  }
  
  
  protected ArrayList calculateTickMarksForXAxisDate() {
    ArrayList coordinates = new ArrayList();
    Calendar cal = Calendar.getInstance();
    Date currentDate = new Date((long)(xMinRange_*1000));
    Date endDate = new Date((long)(xMaxRange_*1000));
    
    cal.setTime(currentDate);
    
    while (currentDate.before(endDate)) {
      cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
      float xCoord = DataTools.scaleToProcessingWindow( (float)(cal.getTimeInMillis()/1000), xMinRange_, xMaxRange_, width );
      coordinates.add(xCoord);
      if (cal.get(Calendar.MONTH) == 11) {
        cal.roll(Calendar.YEAR, 1);
      }
      cal.roll(Calendar.MONTH, 1);
      currentDate = cal.getTime();
    }
    return coordinates;
  }
  
  protected ArrayList calculateTickMarksForXAxisTime() {
    ArrayList coordinates = new ArrayList();
    // Time is currently in seconds from midnight
    int startHoursFromMidnight = (int)((xMinRange_ / 60) / 60);
    int endHoursFromMidnight = (int)((xMaxRange_ / 60) / 60);
    // Want to put a tick mark for each hour
    int numHoursDisplay = endHoursFromMidnight - startHoursFromMidnight;
    println(numHoursDisplay);
    
    for (int i = 0; i < numHoursDisplay; i++) {
      startHoursFromMidnight++;
      float xCoord = DataTools.scaleToProcessingWindow((float)(startHoursFromMidnight*60*60), xMinRange_, xMaxRange_, width);
      coordinates.add(xCoord);
    }
    
    return coordinates;
  }
  
  
  
  protected ArrayList caluclateTickMarksForYAxisDate() {
    ArrayList coordinates = new ArrayList();
    Calendar cal = Calendar.getInstance();
    Date currentDate = new Date((long)(yMinRange_*1000));
    Date endDate = new Date((long)(yMaxRange_*1000));
    
    cal.setTime(currentDate);
    
    while (currentDate.before(endDate)) {
      cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
      float yCoord = height - DataTools.scaleToProcessingWindow((float)(cal.getTimeInMillis()/1000), yMinRange_, yMaxRange_, height);
      coordinates.add(yCoord);
      if (cal.get(Calendar.MONTH) == 11) {
        cal.roll(Calendar.YEAR, 1);
      }
      cal.roll(Calendar.MONTH, 1);
      currentDate = cal.getTime();
    }
    return coordinates;
  }
  
  protected ArrayList calculateTickMarksForYAxisTime() {
    ArrayList coordinates = new ArrayList();
    // Time is currently in seconds from midnight
    int startHoursFromMidnight = (int)((yMinRange_ / 60) / 60);
    int endHoursFromMidnight = (int)((yMaxRange_ / 60) / 60);
    // Want to put a tick mark for each hour
    int numHoursDisplay = endHoursFromMidnight - startHoursFromMidnight;
    println(numHoursDisplay);
    
    for (int i = 0; i < numHoursDisplay; i++) {
      startHoursFromMidnight++;
      float yCoord = height - DataTools.scaleToProcessingWindow((float)(startHoursFromMidnight*60*60), yMinRange_, yMaxRange_, width);
      coordinates.add(yCoord);
    }
    
    return coordinates;
  }

}





/*
* Author: Marissa Mocenigo
* Date: January 2013
* Draws and manages each individual data point
*/

public class GraphPoint {
  float xValue_, yValue_;
  Float scaledXValue_, scaledYValue_;
  int pointRadius_;
  String xHeader_, yHeader_;
  String xString_, yString_;
  boolean active_;
  
  public GraphPoint(String x, String y) {
    xString_ = x;
    yString_ = y;
    scaledXValue_ = null;
    scaledYValue_ = null;
    active_ = true;
    
    // Default
    pointRadius_ = 8;
    
    setX(x);
    setY(y);
  }
  
  public void setX(String x) {
    xValue_ = translateStringValue(x);
  }
  
  public void setY(String y) {
    yValue_ = translateStringValue(y);
  }
  
  public float getX() {
    return xValue_;
  }
  
  public void recalculate() {
    scaledXValue_ = null;
    scaledYValue_ = null;
  }
  
  public float getScaledX(float xMin, float xMax) {
    return DataTools.scaleToProcessingWindow(xValue_, xMin, xMax, width);
  }
  
  public float getScaledY(float yMin, float yMax) {
    return height - DataTools.scaleToProcessingWindow(yValue_, yMin, yMax, height);
  }
  
  public float getY() {
    return yValue_;
  }
  
  public void drawPoint(float xMin, float xMax, float yMin, float yMax) {
    if ((active_) && (xMin <= xValue_) && (xValue_ <= xMax) && (yMin <= yValue_) && (yValue_ <= yMax)) {
      if ((scaledXValue_ == null) || (scaledYValue_ == null)) {
       scaledXValue_ = new Float(DataTools.scaleToProcessingWindow(xValue_, xMin, xMax, width));
       scaledYValue_ = new Float(height - DataTools.scaleToProcessingWindow(yValue_, yMin, yMax, height));
      }
    
      stroke(0xff227077);
      strokeWeight(0.5f);
      fill(0xff38c8d5);
      ellipse(scaledXValue_, scaledYValue_, pointRadius_, pointRadius_);
    
      if (overPoint(scaledXValue_.intValue(), scaledYValue_.intValue(), pointRadius_*2)) {
        drawToolTip(scaledXValue_, scaledYValue_);
      }
    }
  }
  
  private float translateStringValue(String value) {
     if (DataTools.isDateValid(value)) {
      return DataTools.dayInSec(value);
    } 
    if (DataTools.isTimeValid(value)) {
      return DataTools.timeToSecFromMidnight(value);
    } 
    if (DataTools.isNumeric(value)) {
      if (value.contains("$")) {
        StringBuilder strippedString = new StringBuilder(value);
        strippedString.deleteCharAt(value.indexOf("$"));
        value = strippedString.toString();
      }
      return new Float(value);
    }
    return 0;
  }
  
  public void drawToolTip(float xOrigin, float yOrigin) {
    int fontSize = 14;
    int textMargin = 5;

    textSize(fontSize);
    String textString = xString_ + " , " + yString_;
    
    int rectWidth = (int)textWidth(textString) + 2*(textMargin);
    int rectHeight = fontSize + (textMargin);
    stroke(0xffCCCCCC);
    strokeWeight(1);
    fill(255);
    
    if ((xOrigin + rectWidth) > width) {
      rect((xOrigin - rectWidth) + textMargin, yOrigin - rectHeight, rectWidth, rectHeight);
      textAlign(RIGHT);
    } else {
      rect(xOrigin, yOrigin - rectHeight, rectWidth, rectHeight);
      textAlign(LEFT);
    }
    fill(0);
    text(textString, xOrigin + textMargin, yOrigin - textMargin);
  }
  
  private boolean overPoint(int x, int y, int diameter) {
    float disX = x - mouseX;
    float disY = y - mouseY;
    if(sqrt(sq(disX) + sq(disY)) < diameter/2 ) {
      return true;
    } else {
      return false;
    } 
  }
   
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "PointOfSaleGraph" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
