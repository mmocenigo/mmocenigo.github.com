/* 
Marissa A. Mocenigo
Tuesday, April 21, 2009


Finds integer characters within filename and converts them to an integer year
*/


#include "main.h"
#include "llist.h"
#include "extern.h"

int
getYearFromName(char *name) {
    char *cptr;
    int  digits = 0;
    int  wasdigit = 0;
    int  year = 0;
    int  len = strlen(name);

    if (len >= 4) {
	for (cptr = &name[len - 1]; cptr - name >= 0; cptr--) {
	    if (!wasdigit)
		digits = 0;
	    if (*cptr >= '0' && *cptr <= '9') { // a digit
		wasdigit = 1;
		digits++;
		if (digits == 4) { //Finds 4 consecutive digit characters in file name
		    year = atoi(cptr);
		    break;
		}
	    } else wasdigit = 0;
	}
    }

    return(year);
}
    
