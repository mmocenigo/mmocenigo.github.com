/* 
Marissa A. Mocenigo
Tuesday, April 21, 2009

This program takes the data from either a file or stdin and adds the name and data to the linked list. There is one linked list for males and one for females.


 */


#include "main.h"
#include "llist.h"
#include "extern.h"



void
get_data(FILE *fp, int year) {
  Name *name, *tmp;
  Data *dat;
  int male_num, female_num, ret, rank_num;
  char male_name[50], female_name[50];

  while (TRUE) {
    ret = fscanf(fp, "%d %s %d %s %d\n", &rank_num, male_name, &male_num, female_name, &female_num);

    if (ret == EOF) {
      break;
    }
 
    if ((tmp = search(female_name, fhead, ftail)) == NULL) {
      dat = savedata(year, rank_num, female_num); //Save data
      name = makename(female_name); //Save name (only when new)
      append_data(name, dat); //Connect data & name
      append_femname(name); //Connect name
    } else {
      if (year != 0) { //0 indicates stdin
	dat = savedata(year, rank_num, female_num);
	append_data(tmp, dat);
      } else {
	tmp->head->usage += female_num; //Currently not equipped to update rank
      }
    }

    if ((tmp = search(male_name, mhead, mtail)) == NULL) {
      dat = savedata(year, rank_num, female_num);
      name = makename(male_name);
      append_data(name, dat);
      append_malname(name);
    } else {
      if (year != 0) { //0 indicates stdin
	dat = savedata(year, rank_num, female_num);
	append_data(tmp, dat);
      } else {
	tmp->head->usage += male_num; //Currently not equipped to update rank
      }
    }
    
  }
}
