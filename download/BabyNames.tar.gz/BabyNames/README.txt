Marissa A. Mocenigo
April 21, 2009

COMPILE USING:
gcc -g -Wall main.c llist.c get_data.c getYearFromName.c printlist.c process.c -o HW7
OR
make (Makefile included)

COMMAND LINE FORMAT:
[EXECUTABLE (./babynames)] -h [NAME] [FILE (optional)]

If no files are entered, program will take input from stdin (UNIX piping is possible).

Program will only print years for which there is data. Also, reading from stdin will only return a total, as there is no differentiation between years. Also, when reading from stdin, a new node is created for the data (hanging from name); however, no more nodes are added as more occurrences of the name are found. Instead, a total is formulated. This does not include total rank but could, by modifying the rank function of previous assignments.



