/* 
Marissa A. Mocenigo
Tuesday, April 21, 2009

Basic libraries and TRUE/FALSE declaration (which I don't think I ever use?).

*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum{FALSE, TRUE};


