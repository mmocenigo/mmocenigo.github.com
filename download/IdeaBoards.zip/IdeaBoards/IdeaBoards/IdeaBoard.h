//
//  IdeaBoard.h
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/25/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import <Foundation/Foundation.h>

/*
 * Represents the contents of a single 'board'
 * Contains individual ideas (image, note)
 */

@class Idea;

@interface IdeaBoard : NSObject <NSCoding>

@property (nonatomic) NSString *boardName;
@property (nonatomic) NSDate *dateCreated;

@property (nonatomic, readonly) NSArray *allIdeas;

- (instancetype)initWithBoardName:(NSString *)name;

- (Idea *)addNewIdea:(NSString *)note;
- (NSUInteger)getIdeaCount;

- (void)removeIdea:(Idea*) idea;
- (void)removeAll;

// Save
- (void)encodeWithCoder:(NSCoder *)aCoder;
- (instancetype)initWithCoder:(NSCoder *)aDecoder;


@end
