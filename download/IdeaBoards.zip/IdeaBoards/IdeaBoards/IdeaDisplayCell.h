//
//  IdeaDisplayCell.h
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/26/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IdeaDisplayCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *imagePreview;
@property (strong, nonatomic) IBOutlet UILabel *dateLabel;
@property (strong, nonatomic) IBOutlet UILabel *noteLabel;

- (void)setNoteFromString:(NSString *)value;
- (void)setDateFromNSDate:(NSDate *)date;
- (void)setImageFromString:(NSString *)image;


@end
