//
//  IdeaBoardViewController.h
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/26/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import <UIKit/UIKit.h>

/*
 * This manages the data to view relationship for an individual board
 */

@class IdeaBoard;

@interface IdeaBoardViewController: UITableViewController <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic) IdeaBoard *activeBoard;

@end
