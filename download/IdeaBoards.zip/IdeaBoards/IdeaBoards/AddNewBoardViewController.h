//
//  AddNewBoardViewController.h
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/26/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import <UIKit/UIKit.h>

/*
 * This manages the data to view relationship for adding a new board
 */

@interface AddNewBoardViewController: UIViewController

@property (nonatomic, strong) IBOutlet UITextField *BoardNameInput;

- (IBAction)CreateNewBoard:(id)sender;

@end
