//
//  AddNewBoardViewController.h
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/26/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import <UIKit/UIKit.h>

/*
 * This manages the data to view relationship for adding a new board
 */

@interface AddNewBoardViewController: UIViewController<UITextFieldDelegate>

@property (nonatomic, strong) IBOutlet UITextField *BoardNameInput;

extern const int MAX_LENGTH_BOARD_NAME;

- (IBAction)CreateNewBoard:(id)sender;
- (IBAction)CancelRequest:(id)sender;

@end
