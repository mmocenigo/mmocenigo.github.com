//
//  IdeaBoardsViewController.m
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/25/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import "IdeaBoardViewController.h"
#import "AddPhotoViewController.h"
#import "IdeaBoard.h"
#import "Idea.h"
#import "ImageOrganizer.h"
#import "DisplayIdeaCell.h"


@implementation IdeaBoardViewController

- (id)init
{
    self = [super initWithStyle:UITableViewStylePlain];
    return self;
}

- (id)initWithStyle:(UITableViewStyle)style
{
    return [self init];
}

- (void)setActiveBoard:(IdeaBoard *)activeBoard
{
    _activeBoard = activeBoard;
    self.navigationItem.title = _activeBoard.boardName;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (!_activeBoard)
    {
        return 0;
    }
    return _activeBoard.getIdeaCount;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"DisplayIdeaCell";
    
    DisplayIdeaCell *cell = [tableView
                              dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[DisplayIdeaCell alloc]
                initWithStyle:UITableViewCellStyleDefault
                reuseIdentifier:cellIdentifier];
    }
    
    NSArray *ideas = _activeBoard.allIdeas;
    Idea *idea = ideas[indexPath.row];
    
    cell.dateLabel.text = idea.getDateCreated;
    cell.noteLabel.text = idea.note;
    UIImage *cellImage = [[ImageOrganizer sharedStore] imageForKey:idea.imageKey];
    if (!cellImage)
    {
        cellImage = [UIImage imageNamed:@"photo_unavailable.png"];
    }
    cell.viewImage.image = cellImage;
    
    return cell;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    NSLog(@"Identifier: %@", [segue identifier]);
    if ([[segue identifier] isEqualToString:@"addPhoto"]) {
        AddPhotoViewController *photoController = [segue destinationViewController];
        if (photoController)
        {
            [photoController setActiveBoard:self.activeBoard];
        }
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    // Make sure the table is up-to-date
    [self.tableView reloadData];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 390;
}

@end
