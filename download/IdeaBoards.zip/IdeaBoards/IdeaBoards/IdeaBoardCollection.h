//
//  IdeaBoardCollection.h
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/25/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import <Foundation/Foundation.h>

/*
 *  Singleton class which keeps track of each individual board
 *  at any given time. Boards are made up of smaller
 *  'ideas', containing an image and note.
 */

@class IdeaBoard;

@interface IdeaBoardCollection : NSObject

// Prevent the receiver from messing with the real goods
@property (nonatomic, readonly) NSArray *allBoards;

// The singleton instance
+ (instancetype)sharedCollection;

// Creates a new board using the string
- (IdeaBoard *)addNewBoard:(NSString *)name;
- (void)removeBoardAtIndex:(NSInteger)index;

// Writes out the application data to a file... hopefully. Kinda buggy right now.
- (BOOL)saveChanges;

@end
