//
//  AddPhotoViewController.m
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/26/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import "AddPhotoViewController.h"
#include "Idea.h"
#include "IdeaBoard.h"
#include "ImageOrganizer.h"

@implementation AddPhotoViewController

@synthesize IdeaNoteField;
@synthesize photo;

const int MAX_LENGTH_NOTE = 35;


- (void)setActiveBoard:(IdeaBoard *)activeBoard
{
    _activeBoard = activeBoard;
}

- (void)applyFilter:(NSString *)filterName
{
    UIImageOrientation orientation = [photo.image imageOrientation];
    CIImage *ciImage = [[CIImage alloc] initWithImage:photo.image];
    
    CIFilter *filter = [CIFilter filterWithName:filterName
                                  keysAndValues:kCIInputImageKey, ciImage, nil];
    [filter setDefaults];
    if ([filterName isEqualToString:@"CIVignette"])
    {
        [filter setValue: [NSNumber numberWithFloat: 5.0] forKey: @"inputIntensity"];
    }
    else if ([filterName isEqualToString:@"CIVibrance"])
    {
        [filter setValue: [NSNumber numberWithFloat: 0.9] forKey: @"inputAmount"];
    }
    
    CIContext *context = [CIContext contextWithOptions:nil];
    CIImage *outputImage = [filter outputImage];
    CGImageRef cgImage = [context createCGImage:outputImage
                                       fromRect:[outputImage extent]];
    
    photo.image = [UIImage imageWithCGImage:cgImage scale:1.0 orientation:orientation];
    
    CGImageRelease(cgImage);
}

- (IBAction)addVibranceToPhoto:(id)sender
{
    [self applyFilter:@"CIVibrance"];
}

- (IBAction)addSepiaToPhoto:(id)sender
{
    [self applyFilter:@"CISepiaTone"];
}

- (IBAction)addVignetteToPhoto:(id)sender
{
    [self applyFilter:@"CIVignette"];
}

- (IBAction)addFadeToPhoto:(id)sender
{
    [self applyFilter:@"CIPhotoEffectFade"];
}

- (IBAction)saveIdeaRequested:(id)sender
{
    Idea *newIdea = [_activeBoard addNewIdea:IdeaNoteField.text];
    NSLog(@"Idea created. Save image with key: %@", newIdea.imageKey);
    [[ImageOrganizer sharedStore] setImage:photo.image forKey:newIdea.imageKey];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)openImagePickerBySource:(UIImagePickerControllerSourceType)source
{
    if (![UIImagePickerController isSourceTypeAvailable:source]){
        return;
    }
    
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    
    imagePicker.sourceType = source;
    imagePicker.editing = YES;
    imagePicker.delegate = (id)self;
    
    [self presentViewController:imagePicker animated:YES completion:nil];
}

- (IBAction)takePhotoRequested:(id)sender
{
    [self openImagePickerBySource:UIImagePickerControllerSourceTypeCamera];
}

- (IBAction)selectPhotoRequested:(id)sender
{
    [self openImagePickerBySource:UIImagePickerControllerSourceTypePhotoLibrary];

}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
	UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    photo.image = [self scaleImage:image];
    [picker dismissViewControllerAnimated:NO completion:nil];
}

- (UIImage *)scaleImage:(UIImage *)image {
    CGFloat scaleBy = 1.0;
    CGSize frameSize = photo.frame.size;
    
    //Deciding which factor to use to scale the image (factor = targetSize / imageSize)
    if (image.size.width > frameSize.width || image.size.height > frameSize.height)
    {
        scaleBy = (frameSize.width / image.size.width);
        if (!(scaleBy > (frameSize.height / image.size.height)))
        {
            scaleBy = frameSize.height / image.size.height;
        }
    }
    
    UIGraphicsBeginImageContext(frameSize);
    
    //Creating the rect where the scaled image is drawn in
    CGRect rect = CGRectMake((frameSize.width- image.size.width * scaleBy) / 2,
                             (frameSize.height -  image.size.height * scaleBy) / 2,
                             image.size.width * scaleBy, image.size.height * scaleBy);
    
    //Draw the image into the rect
    [image drawInRect:rect];
    
    //Saving the image, ending image context
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return scaledImage;
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:NO completion:nil];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.text.length >= MAX_LENGTH_NOTE && range.length == 0)
    {
        return NO;
    }
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [IdeaNoteField resignFirstResponder];
    return NO;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    UITouch *touch = [[event allTouches] anyObject];
    if ([IdeaNoteField isFirstResponder] && [touch view] != IdeaNoteField) {
        [IdeaNoteField resignFirstResponder];
    }
    [super touchesBegan:touches withEvent:event];
}


@end
