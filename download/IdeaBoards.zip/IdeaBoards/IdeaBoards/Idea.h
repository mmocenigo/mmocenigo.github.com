//
//  Idea.h
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/26/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Idea : NSObject <NSCoding>

@property (nonatomic, readonly) NSString *note;
@property (nonatomic, readonly, copy) NSDate *dateCreated;
@property (nonatomic, copy) NSString *imageKey;

- (instancetype)initWithNote:(NSString *)text;

- (NSString *)getDateCreated;

-(void) removeImage;

- (void)encodeWithCoder:(NSCoder *)aCoder;
- (instancetype)initWithCoder:(NSCoder *)aDecoder;

@end
