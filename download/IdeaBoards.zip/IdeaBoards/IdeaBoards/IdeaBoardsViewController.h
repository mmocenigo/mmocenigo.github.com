//
//  IdeaBoardsViewController.h
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/25/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import <UIKit/UIKit.h>

/*
 * This manages the data to view relationship for a list of boards
 */

@interface IdeaBoardsViewController: UITableViewController <UITableViewDelegate, UITableViewDataSource>

@end
