//
//  IdeaBoard.m
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/25/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import "IdeaBoard.h"
#include "Idea.h"

@interface IdeaBoard ()

@property (nonatomic) NSMutableArray *privateIdeas;

@end

@implementation IdeaBoard

- (instancetype)initWithBoardName:(NSString *)name
{
    // Always init super
    self = [super init];
    
    if (self)
    {
        _boardName = name;
        _dateCreated = [[NSDate alloc] init];
        _privateIdeas = [[NSMutableArray alloc] init];
    }
    
    return self;
}

- (instancetype)init
{
    return [self initWithBoardName:@"Unknown"];
}

- (Idea *)addNewIdea:(NSString *)note
{
    Idea *newIdea = [[Idea alloc] initWithNote:note];
    [self.privateIdeas addObject:newIdea];
    return newIdea;
}

- (NSArray *)allIdeas
{
    return self.privateIdeas;
}


- (NSUInteger)getIdeaCount
{
    return [self.privateIdeas count];
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.boardName forKey:@"boardName"];
    [aCoder encodeObject:self.dateCreated forKey:@"dateCreated"];
    [aCoder encodeObject:self.privateIdeas forKey:@"ideas"];
}

- (void)removeIdea:(Idea*) idea
{
    [self.privateIdeas removeObject:idea];
}

- (void)removeAll
{
    for(int i =0; i < self.privateIdeas.count; i++)
    {
        [self.privateIdeas[i] removeImage];
    }
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if (self)
    {
        _boardName = [aDecoder decodeObjectForKey:@"boardName"];
        _dateCreated = [aDecoder decodeObjectForKey:@"dateCreated"];
        _privateIdeas = [aDecoder decodeObjectForKey:@"ideas"];
    }
    return self;
}

@end
