//
//  IdeaDetailViewController.m
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/26/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import "IdeaDetailViewController.h"

@interface IdeaDetailViewController ()

@property (nonatomic, weak) IBOutlet UILabel *noteContent;
@property (nonatomic, weak) IBOutlet UIImageView *ideaImage;

@end

@implementation IdeaDetailViewController

@end
