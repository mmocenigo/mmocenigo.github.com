//
//  AddNewBoardViewController.m
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/26/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import "AddNewBoardViewController.h"
#import "IdeaBoardCollection.h"
#import "IdeaBoard.h"


@implementation AddNewBoardViewController

@synthesize BoardNameInput;

- (IBAction)CreateNewBoard:(id)sender {
    NSString *boardName = BoardNameInput.text;
    if (![boardName isEqualToString:@""])
    {
        [[IdeaBoardCollection sharedCollection] addNewBoard:boardName];
        BoardNameInput.text = @"";
    }
    [self.navigationController popViewControllerAnimated:YES];
}

@end
