//
//  AddNewBoardViewController.m
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/26/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import "AddNewBoardViewController.h"
#import "IdeaBoardCollection.h"
#import "IdeaBoard.h"


@implementation AddNewBoardViewController

@synthesize BoardNameInput;

const int MAX_LENGTH_BOARD_NAME = 30;

- (IBAction)CreateNewBoard:(id)sender {
    NSString *boardName = BoardNameInput.text;
    if (![boardName isEqualToString:@""])
    {
        [[IdeaBoardCollection sharedCollection] addNewBoard:boardName];
        BoardNameInput.text = @"";
    }
    [self dismissViewControllerAnimated:NO completion:nil];
}

- (IBAction)CancelRequest:(id)sender
{
    [self dismissViewControllerAnimated:NO completion:nil];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.text.length >= MAX_LENGTH_BOARD_NAME && range.length == 0)
    {
        return NO;
    }
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [BoardNameInput resignFirstResponder];
    return NO;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    UITouch *touch = [[event allTouches] anyObject];
    if ([BoardNameInput isFirstResponder] && [touch view] != BoardNameInput) {
        [BoardNameInput resignFirstResponder];
    }
    [super touchesBegan:touches withEvent:event];
}

@end
