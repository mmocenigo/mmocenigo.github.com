//
//  IdeaCollection.m
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/26/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import "IdeaCollection.h"

@implementation IdeaCollection

@end
