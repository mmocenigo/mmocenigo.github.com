//
//  ImageOrganizer.m
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/26/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import "ImageOrganizer.h"

@interface ImageOrganizer ()

@property (nonatomic, strong) NSMutableDictionary *imageDictionary;

@end

@implementation ImageOrganizer

+ (instancetype)sharedStore
{
    static ImageOrganizer *sharedStore = nil;
    
    if (!sharedStore)
    {
        sharedStore = [[self alloc] initPrivate];
    }
    return sharedStore;
}

- (instancetype)init
{
    @throw [NSException exceptionWithName:@"Singleton"
                                   reason:@"Use +[ImageOrganizer sharedStore]"
                                 userInfo:nil];
    return nil;
}

- (instancetype)initPrivate
{
    self = [super init];
    
    if (self)
    {
        _imageDictionary = [[NSMutableDictionary alloc] init];
    }
    
    return self;
}

- (void)setImage:(UIImage *)image forKey:(NSString *)key
{
    self.imageDictionary[key] = image;
    
    NSString *imagePath = [self imagePathForKey:key];
    
    NSLog(@"Write out image to file with key: %@", key);
    NSData *data = UIImageJPEGRepresentation(image, 0.5);
    [data writeToFile:imagePath atomically:YES];
}

- (UIImage *)imageForKey:(NSString *)key
{
    UIImage *inDictionary = self.imageDictionary[key];
    if (!inDictionary)
    {
        NSLog(@"Image not available in dictionary. Retrieve from file.");
        NSString *imagePath = [self imagePathForKey:key];
        UIImage *fromFile = [UIImage imageWithContentsOfFile:imagePath];
        
        if (fromFile)
        {
            self.imageDictionary[key] = fromFile;
        }
        else
        {
            NSLog(@"Could not find image at %@", [self imagePathForKey:key]);
            self.imageDictionary[key] = [UIImage imageNamed:@"photo_unavailable.png"];
        }
        return self.imageDictionary[key];
    }
    else
    {
        return inDictionary;
    }
}

- (void)deleteImageForKey:(NSString *)key
{
    if (!key)
    {
        return;
    }
    [self.imageDictionary removeObjectForKey:key];
    
    NSString *imagePath = [self imagePathForKey:key];
    [[NSFileManager defaultManager] removeItemAtPath:imagePath error:nil];
}

- (NSString *)imagePathForKey:(NSString *)key
{
    NSArray *documentDirectories = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *documentDirecory = [documentDirectories firstObject];
    return [documentDirecory stringByAppendingPathComponent:key];
}

@end
