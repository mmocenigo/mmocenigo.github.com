//
//  IdeaBoardsViewController.m
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/25/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import "IdeaBoardsViewController.h"
#import "IdeaBoardViewController.h"
#import "IdeaBoardCollection.h"
#import "IdeaBoard.h"

@implementation IdeaBoardsViewController


- (id)init
{
    self = [super initWithStyle:UITableViewStylePlain];
    return self;
}

- (id)initWithStyle:(UITableViewStyle)style
{
    return [self init];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[[IdeaBoardCollection sharedCollection] allBoards] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *tableIdentifier = @"IdeaBoardCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:tableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:tableIdentifier];
    }
    
    NSArray *boards = [[IdeaBoardCollection sharedCollection] allBoards];
    IdeaBoard *board = boards[indexPath.row];
    
    cell.textLabel.text = board.boardName;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%lu %@", (unsigned long)board.getIdeaCount, @"Ideas"];
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [[IdeaBoardCollection sharedCollection] removeBoardAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"openIdeaBoard"]) {
        IdeaBoardViewController *displayIdeaBoard = [segue destinationViewController];
        if (displayIdeaBoard)
        {
            NSArray *boards = [[IdeaBoardCollection sharedCollection] allBoards];
            NSIndexPath * ip = [self.tableView indexPathForSelectedRow];
            IdeaBoard *board = boards[ip.row];
            displayIdeaBoard.activeBoard = board;
        }
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    // Make sure the table is up-to-date
    [self.tableView reloadData];
}

@end
