//
//  Idea.m
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/26/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import "Idea.h"
#import "ImageOrganizer.h"

@implementation Idea

- (instancetype)initWithNote:(NSString *)text
{
    self = [super init];
    if (self)
    {
        _note = text;
        _dateCreated = [[NSDate alloc] init];
        _imageKey = [[[NSUUID alloc] init] UUIDString];
    }
    return self;
}

- (NSString *)getDateCreated
{
    NSLocale *locale = [NSLocale currentLocale];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSString *dateFormat = [NSDateFormatter dateFormatFromTemplate:@"E MMM d yyyy" options:0 locale:locale];
    [formatter setDateFormat:dateFormat];
    [formatter setLocale:locale];
    
    return [formatter stringFromDate:_dateCreated];
}

-(void) removeImage
{
    [[ImageOrganizer sharedStore] deleteImageForKey:self.imageKey];
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.note forKey:@"ideaNote"];
    [aCoder encodeObject:self.dateCreated forKey:@"dateCreated"];
    [aCoder encodeObject:self.imageKey forKey:@"imageKey"];
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if (self)
    {
      _note = [aDecoder decodeObjectForKey:@"ideaNote"];
      _dateCreated = [aDecoder decodeObjectForKey:@"dateCreated"];
      _imageKey = [aDecoder decodeObjectForKey:@"imageKey"];
    }
    return self;
}


@end
