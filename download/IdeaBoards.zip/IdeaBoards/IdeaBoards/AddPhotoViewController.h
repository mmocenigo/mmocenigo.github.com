//
//  AddPhotoViewController.h
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/26/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import <UIKit/UIKit.h>

/*
 * This manages the data to view relationship for adding photos and filters.
 */

@class IdeaBoard;

@interface AddPhotoViewController : UIViewController<UIImagePickerControllerDelegate, UITextFieldDelegate>

@property (nonatomic) IdeaBoard *activeBoard;

@property (weak, nonatomic) IBOutlet UITextField *IdeaNoteField;
@property (weak, nonatomic) IBOutlet UIImageView *photo;

extern const int MAX_LENGTH_NOTE;

- (void)applyFilter:(NSString *)filterName;
- (IBAction)addVibranceToPhoto:(id)sender;
- (IBAction)addSepiaToPhoto:(id)sender;
- (IBAction)addVignetteToPhoto:(id)sender;
- (IBAction)addFadeToPhoto:(id)sender;

- (UIImage *)scaleImage:(UIImage *)image;

- (IBAction)saveIdeaRequested:(id)sender;

- (IBAction)takePhotoRequested:(id)sender;
- (IBAction)selectPhotoRequested:(id)sender;

@end
