//
//  IdeaDisplayCell.m
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/26/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import "IdeaDisplayCell.h"

@implementation IdeaDisplayCell

@synthesize dateLabel = _dateLabel;
@synthesize noteLabel = _noteLabel;
@synthesize imagePreview = _imagePreview;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setNoteFromString:(NSString *)value
{
    NSLog(@"Set note");
    _noteLabel.text = value;
}

- (void)setDateFromNSDate:(NSDate *)date
{
    NSLocale *locale = [NSLocale currentLocale];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSString *dateFormat = [NSDateFormatter dateFormatFromTemplate:@"E MMM d yyyy" options:0 locale:locale];
    [formatter setDateFormat:dateFormat];
    [formatter setLocale:locale];
    
    _dateLabel.text = [formatter stringFromDate:date];
}

- (void)setImageFromString:(NSString *)image
{
    NSLog(@"Set Image");
    _imagePreview.image = [UIImage imageNamed:image];
}

@end
