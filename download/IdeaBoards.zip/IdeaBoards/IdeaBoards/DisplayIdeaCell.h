//
//  DisplayIdeaCell.h
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/26/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import <UIKit/UIKit.h>

/*
 * This class provides a custom table cell for the large
 * image displays in the board 'feed'
 *
 */

@interface DisplayIdeaCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *viewImage;
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UILabel *noteLabel;

@end
