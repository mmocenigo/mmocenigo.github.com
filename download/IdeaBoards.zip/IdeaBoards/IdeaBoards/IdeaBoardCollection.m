//
//  IdeaBoardCollection.m
//  IdeaBoards
//
//  Created by Marissa Mocenigo on 4/25/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import "IdeaBoardCollection.h"
#import "IdeaBoard.h"

@interface IdeaBoardCollection ()

@property (nonatomic) NSMutableArray *privateBoards;

@end

@implementation IdeaBoardCollection

- (instancetype)init
{
    // What are you doing? You shouldn't be using this initializer!
    @throw [NSException exceptionWithName:@"Singleton"
                                   reason:@"Use +[IdeaBoardCollection sharedCollection]"
                                 userInfo:nil];
    return nil;
}

- (instancetype)initPrivate
{
    self = [super init];
    if (self)
    {
        NSString *path = [self itemArchivePath];
        _privateBoards = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
        
        if (!_privateBoards)
        {
          _privateBoards = [[NSMutableArray alloc] init];
        }
    }
    return self;
}

- (NSArray *)allBoards
{
    return self.privateBoards;
}

- (IdeaBoard *)addNewBoard:(NSString *)name
{
    IdeaBoard *board = [[IdeaBoard alloc] initWithBoardName:name];
    [self.privateBoards addObject:board];
    return board;
}

- (void)removeBoardAtIndex:(NSInteger)index
{
    IdeaBoard* boardToRemove = [self.privateBoards objectAtIndex:index];
    [boardToRemove removeAll];
    [self.privateBoards removeObjectAtIndex:index];
}

+ (instancetype)sharedCollection
{
    static IdeaBoardCollection *sharedCollection = nil;
    
    if (!sharedCollection)
    {
        sharedCollection = [[self alloc] initPrivate];
    }
    return sharedCollection;
}

- (NSString *)itemArchivePath
{
    NSArray *documentDirectories = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentDir = [documentDirectories firstObject];
    return [documentDir stringByAppendingPathComponent:@"items.archive"];
}

- (BOOL)saveChanges
{
    NSString *path = [self itemArchivePath];
    return [NSKeyedArchiver archiveRootObject:self.privateBoards toFile:path];
}

@end
