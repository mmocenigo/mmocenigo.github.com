//
//  IdeaBoardsTests.m
//  IdeaBoardsTests
//
//  Created by Marissa Mocenigo on 4/25/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import "IdeaBoardsTests.h"

@implementation IdeaBoardsTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"Unit tests are not implemented yet in IdeaBoardsTests");
}

@end
