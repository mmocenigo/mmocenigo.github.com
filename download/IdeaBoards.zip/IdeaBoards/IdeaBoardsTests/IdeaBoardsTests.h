//
//  IdeaBoardsTests.h
//  IdeaBoardsTests
//
//  Created by Marissa Mocenigo on 4/25/14.
//  Copyright (c) 2014 Marissa Mocenigo. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface IdeaBoardsTests : XCTestCase

@end
